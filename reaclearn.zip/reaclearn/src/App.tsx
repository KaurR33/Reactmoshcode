import Message from "./message";
import ListGroup from "./components/ListGroup";
import Alert from "./components/Alert";
import Button from "./components/Button";
import { useState } from "react";
function App(){
  let items = ["tokyo", "Delhi", "texas", "toronto", "vancouver"];
  const handleSelectItem = (item : string)=>{
    console.log(item);
  }

  const [valueToBeChanged, ChangedValue] = useState(false);
  

  return <div>
    <ListGroup items={items} heading="cities" onSelectItem={handleSelectItem}/>
    {valueToBeChanged && <Alert onClose={()=>ChangedValue(false)}> anyting <b>antttt</b></Alert>}
    <Button color="danger" children="a button" onClick={()=>{ChangedValue(true)}}></Button>
  
  </div>;
  
}

export default App;