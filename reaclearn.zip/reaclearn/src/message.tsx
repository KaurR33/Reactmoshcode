function Message(){
    return <h1>hiiii</h1>;
}
export default Message;